var bufferFactory = require('buffer-factory');

var buf = bufferFactory('2b', 'hex')
console.log(buf);

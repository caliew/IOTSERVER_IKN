declare module 'buffer-factory';

export function create(...bufferParams: any[]): Buffer;
export default function bufferFactory(...bufferParams: any[]): Buffer;